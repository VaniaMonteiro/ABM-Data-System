﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            string edifact = @"UNA:+.? '
            UNB+UNOC:3+2021000969+4441963198+180525:1225+3VAL2MJV6EH9IX+KMSV7HMD+CUSDECU-IE++1++1'
            UNH+EDIFACT+CUSDEC:D:96B:UN:145050'
            BGM+ZEM:::EX+09SEE7JPUV5HC06IC6+Z'
            LOC+17+IT044100'
            LOC+18+SOL'
            LOC+35+SE'
            LOC+36+TZ'
            LOC+116+SE003033'
            DTM+9:20090527:102'
            DTM+268:20090626:102'
            DTM+182:20090527:102'";

            List<String[]> results = new List<String[]>();

            string[] lines = edifact.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

            for(int i=0; i<lines.Count(); i++)
            {
                string[] items = lines[i].Split('+').ToArray();
                if (items[0].Trim()== "LOC")
                {
                    results.Add(new String[] { items[1], items[2] });
                    Console.WriteLine("Results: " + results.Last().GetValue(0) + " " + results.Last().GetValue(1));
                }
            }
        }
    }
}