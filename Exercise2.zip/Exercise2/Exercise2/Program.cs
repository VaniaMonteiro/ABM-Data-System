﻿using System;
using System.Xml;

namespace Exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlTextReader reader = new XmlTextReader("XMLDocument.xml");
            reader.Read();
            while (reader.Read())
            {
                if(reader.Name == "Reference")
                {
                    switch (reader.GetAttribute("RefCode"))
					{
                        case "MWB":
                            while (reader.Name != "RefText")
                            {
                                reader.Read();
                            }
                            Console.WriteLine(reader.ReadInnerXml());
                            break;
                        case "TRV":
                            while (reader.Name != "RefText")
                            {
                                reader.Read();
                            }
                            Console.WriteLine(reader.ReadInnerXml());
                            break;
                        case "CAR":
                            while (reader.Name != "RefText")
                            {
                                reader.Read();
                            }
                            Console.WriteLine(reader.ReadInnerXml());
                            break;

                    }
                }
            }
        }
    }
}
