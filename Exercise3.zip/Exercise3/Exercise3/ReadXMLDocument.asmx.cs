﻿using System;
using System.Web;
using System.Web.Services;
using System.Xml;

namespace Exercise3
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class ReadXMLDocument : System.Web.Services.WebService
    {
        [WebMethod]
        public int validateXML(XmlDocument xmlDoc)
        {
            int result = 0;
            String name = xmlDoc.DocumentElement.GetElementsByTagName("Declaration").Item(0).Attributes.Item(0).Name;
            String value = xmlDoc.DocumentElement.GetElementsByTagName("Declaration").Item(0).Attributes.Item(0).Value;
            if (name == "Command" && value != "DEFAULT")
            {
                result = -1;
            }
            String siteID = xmlDoc.DocumentElement.GetElementsByTagName("SiteID").Item(0).InnerText;
            if (result == 0 && siteID != "DUB")
            {
                result = -2;
            }
            Console.ReadKey();
            return result;
        }
    }
}
