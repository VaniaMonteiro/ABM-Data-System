﻿using System;
using System.Xml;
using Exercise3.ReadXMLDocument_Ref;

namespace Exercise3
{

    public partial class Default : System.Web.UI.Page
    {
        public void button1Clicked(object sender, EventArgs args)
        {
            ReadXMLDocument webService = new ReadXMLDocument();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("xmlDocument.xml");
            Label1.Text = "Output of WebService: " + webService.validateXML(xmlDoc).ToString();
        }
        public void button2Clicked(object sender, EventArgs args)
        {
            ReadXMLDocument webService = new ReadXMLDocument();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("xmlDocument_Error1.xml");
            Label1.Text = "Output of WebService: " + webService.validateXML(xmlDoc).ToString();
        }
        public void button3Clicked(object sender, EventArgs args)
        {
            ReadXMLDocument webService = new ReadXMLDocument();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("xmlDocument_Error2.xml");
            Label1.Text = "Output of WebService: " + webService.validateXML(xmlDoc).ToString();
        }
    }
}